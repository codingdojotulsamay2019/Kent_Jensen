﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using DojoWithValid.Models;

namespace DojoWithValid.Controllers
{
        public class HomeController : Controller
        {
            [HttpGet("")]
            public IActionResult Index()
            {
                return View();
            }

            [HttpPost("Survey")]
            public IActionResult Survey(Survey yourSurvey)
            {
                if(ModelState.IsValid)
                {
                    return View("Result", yourSurvey);
                }
                else
                {
                    return View("Index", yourSurvey);
                };
            }
            public IActionResult Privacy()
            {
                return View();
            }

            [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
            public IActionResult Error()
            {
                return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
            }


            [HttpGet("Success")]
            public IActionResult Success()
            {
                Console.WriteLine("In success");
                return View("Result");
        }
    }
}