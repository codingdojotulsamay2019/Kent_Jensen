using System.ComponentModel.DataAnnotations;

namespace DojoWithValid.Models
{
    public class Survey
    {
        [Required]
        [MinLength(2)]
        [Display(Name = "name")]
        public string Name {get;set;}
        [Required]
        [Display(Name = "location")]
        public string Location {get;set;}
        [Required]
        [Display(Name = "language")]
        public string Language {get;set;}
        [MinLength(20)]
        [Display(Name = "comment")]
        public string Comment {get;set;}
    }
}