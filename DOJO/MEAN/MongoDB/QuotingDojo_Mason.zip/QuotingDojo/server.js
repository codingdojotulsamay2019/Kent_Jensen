const express = require("express");
const app= express();
//static files
app.use(express.static(__dirname+"/static"));
//vies ejs
app.set("view engine", "ejs");
app.set("views",__dirname+"/views");
//form data
app.use(express.urlencoded({extended: true}));
//Flash
const flash = require('express-flash');
app.use(flash());
//Session
const session = require('express-session');
app.use(session({
  secret: 'keyboardkitteh',
  resave: false,
  saveUninitialized: true,
  cookie: { maxAge: 60000 }
}))
//Mongoose
const mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/QuotingDojo', {useNewUrlParser: true});
const UserQuote= new mongoose.Schema({
    name: { type: String, required: true, minlength:1},
    quote: { type: String, required: true, minlength: 5}
}, {timestamps: true});
const Quote=mongoose.model('Quote', UserQuote);
// root route
app.get("/", (req, res) => {
    console.log("Root Route")
    res.render('index')
})
// POST /quotes
app.post("/quotes", (req,res) => {
    console.log("post /quotes")
    console.log(req.body)
    Quote.create(req.body)
        .then(success => console.log("success!"))
        .catch(err => {
            for(let e in err.errors) {
              console.log(err.errors[e].message);
              req.flash('name', err.errors[e].message);
            }
        })
        .finally(()=> {
              res.redirect('/');
    })
})
// GET /quotes
app.get("/quotes", (req, res) => {
    console.log("get /quotes")
    Quote.find()
        .then(allQuotes => {
            console.log("success!");
            console.log(allQuotes)
            res.render('show', {quotes: allQuotes})
        })
        .catch(err => {
            console.log("******* error:")
            console.log(err);
            res.render('show', {err: err})
        })
})

app.listen(8000, () => console.log ("listeing on port 8000"));