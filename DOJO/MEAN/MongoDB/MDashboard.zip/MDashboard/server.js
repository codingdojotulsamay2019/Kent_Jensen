const express = require("express");
const app = express();
const mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/mdash', {useNewUrlParser: true});

const OtterSchema = new mongoose.Schema({
    name: {type: String, required: [true, 'Name Required'], minlength: 2},
    age: {type: Number, required: [true, 'Age Required']},
    confirmedkills: {type: Number, required: true}
}, {timestamps: true});

const Otter = mongoose.model("Otter", OtterSchema);

app.use(express.urlencoded({extended: true}));
app.use(express.static(__dirname + "/static")); //tells express to use static folder

app.set('views', __dirname + '/views'); //tells ejs where templates are
app.set('view engine', 'ejs');  //sets ejs as view engine





app.get('/', (req, res) => {
    Otter.find()
    .then(allotters => {
        res.render('index', {otters: allotters})
    })
    .catch(err => res.render('index', {err: err}))
    .finally(() => {
        res.render('index');
    })
})

app.get('/otter/show/:id', (req, res) => {
    Otter.findOne({_id: req.params.id})
    .then(totter => {
        console.log("OTTER", totter);
        res.render('show', {otter: totter})
    })
    .catch(err => res.render('/otter/show/'+req.params.id, {err: err}))
})

app.get('/otters/new', (req, res) => {
    res.render('new')
})

app.post('/otters', (req, res) => {
    var id = 0;
    console.log("FORM", req.body);
    Otter.create(req.body)
    .then(success => {
        id = success._id;
        return res.redirect('/otter/show/'+ id)})
    .catch(err => {
        console.log("ERROR", err);
        res.render('new', {err: err})
    })
})

app.get('/otter/edit/:id', (req, res) => {
    Otter.findOne({_id: req.params.id})
    .then(totter => res.render('edit', {otter: totter}))
    .catch(err => res.render('/otter/edit/'+req.params.id, {err: err}))
})

app.post('/otter/update/:id', (req, res) => {
    Otter.updateOne({_id: req.params.id}, req.body)
    .then(success => {
        console.log("SUCCESS",success)
        return res.redirect('/otter/show/'+ req.params.id)})
    .catch(err => {
        console.log("EPIC FAIL",err);
        res.render('/otter/edit/'+req.params.id, {err: err})
    })
})

app.get('/otter/destroy/:id', (req, res) => {
    Otter.remove({_id: req.params.id})
    .then(success => {
        return console.log(success)})
    .catch(err => res.render('/', {err: err}))
    .finally(success => {
        res.redirect('/');
    })
})


app.listen(8000, () => console.log("listening on port 8000"));
